<?php
/** @var yii\web\View $this */
/** @var $alltypes \app\models\TypeWork[] */
/** @var $type \app\models\TypeWork */
/** @var $allworks \app\models\Work[] */

/** @var $work \app\models\Work */
Use yii\helpers\Url;
use yii\helpers\VarDumper;
$is_visible = true;
use yii\helpers\Html;


if(isset($dataProvider)){

}
?>
<div class="reports">
    <div class="header">
        <div class="header-up flex-row">
            <div class="header-up_name">
                Отчеты
            </div>
            <div class="header-up_message">
                <img src="img/message.svg" alt="message" class="message cursor">
                <img src="img/indicator.svg" alt="indicator" class="indicator">
            </div>
        </div>

        <hr>

        <div class="header-down flex-row">
            <div class="search flex-row cursor">
                <a href="<?=  Url::to(["work/index"])?>"></a>
                <img src="img/search.svg" alt="search" class="search_img">


                <?= Html::beginForm(['work/index'], 'POST'); ?>
                <?= Html::input('text', 'query_string', "",  ['class'=>'search_text']) ?>

                    <?= Html::submitButton('POST'); ?>

                <?= Html::endForm(); ?>

<!---->
<!--                <form  method="post" action="/web/index.php?r=work%2Findex" name="form">-->
<!--                    <input type="text" class="search_text" name="search" placeholder="Поиск" />-->
<!--                    <button type="submit" name="submit" > wefewfwe </button>-->
<!--                </form>-->
            </div>

            <div class="filter flex-row cursor">
                <div class="filter_text">
                    Фильтр
                </div>
                <img src="img/filter.svg" alt="filter" class="filter_img">
            </div>
        </div>
    </div>
    <div class="documents">
        <?php foreach ($alltypes as $type): ?>
            <?php if (empty($type->works)) {
                $is_visible = false;
            }
            ?>
            <?php if ($is_visible) : ?>
                <div class="documents-type">
                    <!-- Курсовая работа -->
                    <div class="documents_name">
                        <?= $type->name ?>
                    </div>

                    <div class="documents_table">
                        <table cellspacing="0" cellpadding="0">
                            <tr class="headings">
                                <th class="headings_discipline">Дисциплина</th>
                                <th class="headings_topic">Тема работы</th>
                                <th class="headings_period">Срок</th>
                                <th class="headings_status">Статус</th>
                                <th></th>
                            </tr>
                            <?php

                            for ($i = 0;
                            $i < count($allworks);
                            $i++) {
                            $work = $allworks[$i];
                            ?>
                            <div id="popup" class="popup">
                                <div class="popup_body">
                                    <div class="popup_content">
                                        <div class="popup_header flex-row">
                                            <div class="popup_header-left flex-row">
                                                <div class="popup_title">
                                                    <?= $work->typeWork->name ?>
                                                </div>
                                                <?
                                                $statusClass = '';
                                                switch ($work->status->id) {
                                                    case 1:
                                                        $statusClass = 'completed';
                                                        break;
                                                    case 3:
                                                        $statusClass = 'in-progress';
                                                        break;
                                                    case 2:
                                                        $statusClass = 'overdue';
                                                        break;
                                                    default:
                                                        $statusClass = 'overdue';
                                                        break;
                                                }
                                                ?>
                                                <div class="popup-<?= $statusClass ?>">
                                                    <div class=<?= $statusClass ?>>
                                                        <?= $work->status->name ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="popup_header-right flex-row">
                                                <a href="#" class="popup_message">
                                                    <img src="img/popup_message.svg" alt="popup_message"
                                                         class="popup_message">
                                                </a>
                                                <a href="#" class="popup_close" onclick="closePopup(<?= $i ?>)">
                                                    <img src="img/close.svg" align="close" class="popup_close">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="popup_main flex-row">
                                            <div class="popup_main-left">
                                                <div class="popup_info">
                                                    <div class="popup_name">
                                                        Дисциплина
                                                    </div>

                                                    <div class="popup_text">
                                                        <?= $work->discipline->name ?>
                                                    </div>
                                                </div>

                                                <div class="popup_info">
                                                    <div class="popup_name">
                                                        Тема работы
                                                    </div>

                                                    <div class="popup_text">
                                                        <?= $work->topic ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="popup_main-right">
                                                <div class="popup_info">
                                                    <div class="popup_name">
                                                        Срок
                                                    </div>

                                                    <div class="popup_text">
                                                        <?= strftime("%d.%m.%G", strtotime($work->date_since)) ?>
                                                        -<?= strftime("%d.%m.%G", strtotime($work->date_by)) ?>
                                                    </div>
                                                </div>

                                                <div class="popup_info">
                                                    <div class="popup_name">
                                                        Работа загружена
                                                    </div>

                                                    <div class="popup_text">
                                                        <?= $work->loading ?>
                                                    </div>
                                                </div>

                                                <div class="popup_info">
                                                    <div class="popup_name">
                                                        Оценка
                                                    </div>

                                                    <div class="popup_estimation">
                                                        <?= $work->mark->name ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <hr class="popup_hr">

                                        <div class="popup_buttons">
                                            <a href="#" class="popup_but">Сформировать</a>
                                            <a href="#" class="popup_but">Загрузить</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <?
                    if ($work->typeWork->name == $type->name) {
                        ?>

                        <tr class="line">
                            <td class="line_discipline"><?= $work->discipline->name ?></td>
                            <td class="line_topic"><?= $work->topic ?></td>
                            <td class="line_period"><?= strftime("%d.%m.%G", strtotime($work->date_since)) ?>
                                -<?= strftime("%d.%m.%G", strtotime($work->date_by)) ?> </td>
                            <td class="line_status">
                                <?
                                switch ($work->status->id) {
                                    case 1:
                                        $statusClass = 'completed';
                                        break;
                                    case 3:
                                        $statusClass = 'in-progress';
                                        break;
                                    case 2:
                                        $statusClass = 'overdue';
                                        break;
                                    default:
                                        $statusClass = 'overdue';
                                        break;
                                }
                                ?>

                                <div class=<?= $statusClass ?>>
                                    <?= $work->status->name ?>
                                </div>
                            </td>
                            <td href="#popup" class="popup-link" onclick="openPopup(<?= $i ?>)"><a class="cursor"><img
                                            src="img/more.svg" alt="more" class="more"></a></td>
                        </tr>
                        <?

                    }
                    }
                    ?>

                    </table>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
        <!--            <div class="documents_name">-->
        <!--                Практические работы-->
        <!--            </div>-->
        <!---->
        <!--            <div class="documents_table">-->
        <!--                <table cellspacing="0" cellpadding="0">-->
        <!--                    <tr class="headings">-->
        <!--                        <th class="headings_discipline">Дисциплина</th>-->
        <!--                        <th class="headings_topic">Тема работы</th>-->
        <!--                        <th class="headings_period">Срок</th>-->
        <!--                        <th class="headings_status">Статус</th>-->
        <!--                        <th></th>-->
        <!--                    </tr>-->
        <!---->
        <!--                    <tr class="line cursor">-->
        <!--                        <td class="line_discipline">Проектирование и разраб. инф. сист.</td>-->
        <!--                        <td class="line_topic">Разработка Telegram-бота с системой уведомлений</td>-->
        <!--                        <td class="line_period">04.04.2022-28.04.2022</td>-->
        <!--                        <td class="line_status">-->
        <!--                            <div class="in-progress">-->
        <!--                                В процессе-->
        <!--                            </div>-->
        <!--                        </td>-->
        <!--                        <td href="#popup"  class="popup-link" ><img  src="img/more.svg" alt="more" class="  more"></td>-->
        <!--                    </tr>-->
        <!---->
        <!--                    <tr class="line cursor">-->
        <!--                        <td class="line_discipline">Проектирование и разраб. инф. сист.</td>-->
        <!--                        <td class="line_topic">Разработка Telegram-бота с системой уведомлений</td>-->
        <!--                        <td class="line_period">04.04.2022-28.04.2022</td>-->
        <!--                        <td class="line_status">-->
        <!--                            <div class="overdue">-->
        <!--                                Просрочено-->
        <!--                            </div>-->
        <!--                        </td>-->
        <!--                        <td href="#popup"  class="popup-link"><img src="img/more.svg" alt="more" class="more"></td>-->
        <!--                    </tr>-->
        <!--                </table>-->
        <!--            </div>-->
    </div>
</div>
</div>



