<form method="post">
    <input type="text">
    <button type="submit">dfafdfdf</button>
</form>