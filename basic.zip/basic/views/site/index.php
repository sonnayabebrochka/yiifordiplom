<?php

/** @var yii\web\View $this */

$this->title = 'My Yii Application';
?>
	


