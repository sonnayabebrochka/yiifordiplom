<?php
/** @var yii\web\View $this */
Use yii\helpers\Url;
?>
<h1>search/index</h1>

<p>
    You may change the content of this page by modifying
    the file <a href="<?php Url::to('@views/work/index')?>">fddffffdd</a>
</p>
