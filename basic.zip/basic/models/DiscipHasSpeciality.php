<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "discip_has_speciality".
 *
 * @property int $id
 * @property int $id_spec
 * @property int $id_disc
 *
 * @property Discipline $disc
 * @property Specialty $spec
 */
class DiscipHasSpeciality extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'discip_has_speciality';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_spec', 'id_disc'], 'required'],
            [['id_spec', 'id_disc'], 'integer'],
            [['id_disc'], 'exist', 'skipOnError' => true, 'targetClass' => Discipline::class, 'targetAttribute' => ['id_disc' => 'id']],
            [['id_spec'], 'exist', 'skipOnError' => true, 'targetClass' => Specialty::class, 'targetAttribute' => ['id_spec' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'id_spec' => 'Id Spec',
            'id_disc' => 'Id Disc',
        ];
    }

    /**
     * Gets query for [[Disc]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDisc()
    {
        return $this->hasOne(Discipline::class, ['id' => 'id_disc']);
    }

    /**
     * Gets query for [[Spec]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSpec()
    {
        return $this->hasOne(Specialty::class, ['id' => 'id_spec']);
    }
}
