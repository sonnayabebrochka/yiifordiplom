<?php

namespace app\controllers;

use app\models\Discipline;
use app\models\TypeWork;
use app\models\Work;
use yii\data\ActiveDataProvider;
use yii\helpers\VarDumper;

class WorkController extends \yii\web\Controller
{
    public function actionIndex($search = "")
    {
        $data = \Yii::$app->request->post('query_string');
        $allworks = Work::find();
        if (!empty($data)){

            $allworks->where(['like', 'topic' ,$data ]);
        }
        $findRes = $allworks->all();
        $alltypes = TypeWork::find()->all();

        $allinfo = [];

        return $this->render('index', ['allworks' => $findRes, 'alltypes' => $alltypes]);
    }


    public function actionTest($search = "")
    {
        echo $search;

        return $this->render('test');
    }

    public function actionSearch()
    {
        $allworks = Work::find()->all();
        $alltypes = TypeWork::find()->all();
        $search = \Yii::$app->request->get('search');
        $query = Work::find()->where(['topic', "replace(title, ' ', ''", $search]);
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        return $this->render('index', ['allworks' => $allworks, 'alltypes' => $alltypes, 'dataProvider' => $dataProvider]);
    }
}
