<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;

class SearchController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');

    if(isset($_POST['submit'])) {
        $search -> $_POST['search'];
        $query -> mysqli_fetch_assoc($connect, "SELECT * FROM 'work' WHERE 'topic' LIKE '%$search%' OR 'text' LIKE '%$search%' ");
        while($row = mysqli_fetch_assoc ($query)) echo "h1".$row['topic']."</h1><p>".$row['text']."</p><br>";
    }
}
}?>
