<?php

/** @var yii\web\View $this */
/** @var string $content */

use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap5\Breadcrumbs;
use yii\bootstrap5\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;

AppAsset::register($this);

$this->registerCsrfMetaTags();
$this->registerMetaTag(['charset' => Yii::$app->charset], 'charset');
$this->registerMetaTag(['name' => 'viewport', 'content' => 'width=device-width, initial-scale=1, shrink-to-fit=no']);
$this->registerMetaTag(['name' => 'description', 'content' => $this->params['meta_description'] ?? '']);
$this->registerMetaTag(['name' => 'keywords', 'content' => $this->params['meta_keywords'] ?? '']);
$this->registerLinkTag(['rel' => 'icon', 'type' => 'image/x-icon', 'href' => '@web/favicon.ico']);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body class="d-flex flex-column h-100">
<?php $this->beginBody() ?>

<div class="wraper">
<div class="side-menu lock">
		<div class="account flex-column">
			<img src="img/account_photo.png" alt="account_photo" class="account_photo cursor">
			<div class="account_name">
				Фамилия И.О.
			</div>
		</div>

		<div class="menu">
			<div class="menu-item flex-row cursor">
				<img src="img/menu-item.svg" alt="menu-item" class="menu-item_img">
				<div class="menu-item_text">
					Отчеты
				</div>
			</div>

			<div class="menu-item flex-row cursor">
				<img src="img/menu-item.svg" alt="menu-item" class="menu-item_img">
				<div class="menu-item_text">
					Обсуждения
				</div>
			</div>
		</div>

		<div class="exit flex-row cursor">
			<img src="img/exit.svg" alt="exit" class="exit_img">
			<div class="exit_text">
				Выйти
			</div>
		</div>
	</div>

    
        <?= $content ?>


        </div>

        <script src="./js/popup.js"></script>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
