<?php

/** @var yii\web\View $this */

$this->title = 'My Yii Application';
?>
	


	<div class="reports">
		<div class="header">
			<div class="header-up flex-row">
				<div class="header-up_name">
					Отчеты
				</div>
				<div class="header-up_message">
					<img src="img/message.svg" alt="message" class="message cursor">
					<img src="img/indicator.svg" alt="indicator" class="indicator">
				</div>
			</div>

			<hr>

			<div class="header-down flex-row">
				<div class="search flex-row cursor">
					<img src="img/search.svg" alt="search" class="search_img">
					<div class="search_text">
						Поиск
					</div>
				</div>

				<div class="filter flex-row cursor">
					<div class="filter_text">
						Фильтр
					</div>
					<img src="img/filter.svg" alt="filter" class="filter_img">
				</div>
			</div>
		</div>

		<div class="documents">
			<div class="documents-type">
				<div class="documents_name">
					Курсовые работы
				</div>

				<div class="documents_table">
					<table cellspacing="0" cellpadding="0">
						<tr class="headings">
							<th class="headings_discipline">Дисциплина</th>
							<th class="headings_topic">Тема работы</th>
							<th class="headings_period">Срок</th>
							<th class="headings_status">Статус</th>
							<th></th>
						</tr>

						<tr class="line">
							<td class="line_discipline">Проектирование и разраб. инф. сист.</td>
							<td class="line_topic">Разработка Telegram-бота с системой уведомлений</td>
							<td class="line_period">04.04.2022-28.04.2022</td>
							<td class="line_status">
								<div class="completed">
									Завершено
								</div>
							</td>
							<td href="#popup"  class="popup-link"><a  class="cursor"><img src="img/more.svg" alt="more" class="more"></a></td>
						</tr>
					</table>
				</div>

				<div class="documents_name">
					Практические работы
				</div>

				<div class="documents_table">
					<table cellspacing="0" cellpadding="0">
						<tr class="headings">
							<th class="headings_discipline">Дисциплина</th>
							<th class="headings_topic">Тема работы</th>
							<th class="headings_period">Срок</th>
							<th class="headings_status">Статус</th>
							<th></th>
						</tr>

						<tr class="line cursor">
							<td class="line_discipline">Проектирование и разраб. инф. сист.</td>
							<td class="line_topic">Разработка Telegram-бота с системой уведомлений</td>
							<td class="line_period">04.04.2022-28.04.2022</td>
							<td class="line_status">
								<div class="in-progress">
									В процессе
								</div>
							</td>
							<td href="#popup"  class="popup-link" ><img  src="img/more.svg" alt="more" class="  more"></td>
						</tr>

						<tr class="line cursor">
							<td class="line_discipline">Проектирование и разраб. инф. сист.</td>
							<td class="line_topic">Разработка Telegram-бота с системой уведомлений</td>
							<td class="line_period">04.04.2022-28.04.2022</td>
							<td class="line_status">
								<div class="overdue">
									Просрочено
								</div>
							</td>
							<td href="#popup"  class="popup-link"><img src="img/more.svg" alt="more" class="more"></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>

	<div id="popup" class="popup">
		<div class="popup_body">
			<div class="popup_content">
				<div class="popup_header flex-row">
					<div class="popup_header-left flex-row">
						<div class="popup_title">
							Курсовая работа
						</div>
						<div class="popup-complited">
							Завершено
						</div>
					</div>

					<div class="popup_header-right flex-row">
						<a href="#" class="popup_message">
							<img src="img/popup_message.svg" alt="popup_message" class="popup_message">
						</a>
						<a href="#" class="popup_close">
							<img src="img/close.svg" align="close" class="popup_close">
						</a>
					</div>
				</div>

				<div class="popup_main flex-row">
					<div class="popup_main-left">
						<div class="popup_info">
							<div class="popup_name">
								Дисциплина
							</div>

							<div class="popup_text">
								Проектирование и  разраб. инф. сист.
							</div>
						</div>

						<div class="popup_info">
							<div class="popup_name">
								Тема работы
							</div>

							<div class="popup_text">
								Разработка Telegram-бота с системой уведомлений
							</div>
						</div>
					</div>

					<div class="popup_main-right">
						<div class="popup_info">
							<div class="popup_name">
								Срок
							</div>

							<div class="popup_text">
								04.04.2022 - 28.04.2022
							</div>
						</div>

						<div class="popup_info">
							<div class="popup_name">
								Работа загружена
							</div>

							<div class="popup_text">
								28.04.2022
							</div>
						</div>

						<div class="popup_info">
							<div class="popup_name">
								Оценка
							</div>

							<div class="popup_estimation">
								5
							</div>
						</div>
					</div>
				</div>

				<hr class="popup_hr">

				<div class="popup_buttons">
					<a href="#" class="popup_but">Сформировать</a>
					<a href="#" class="popup_but">Загрузить</a>
				</div>
			</div>
		</div>
	</div>
</div>
